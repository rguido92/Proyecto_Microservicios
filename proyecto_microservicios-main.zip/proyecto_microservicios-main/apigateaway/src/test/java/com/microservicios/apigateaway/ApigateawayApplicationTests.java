package com.microservicios.apigateaway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigateawayApplicationTests {

	@Test
	void contextLoads() {
	}

}
