package com.microservicios.comentarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComentariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComentariosApplication.class, args);
	}

}
